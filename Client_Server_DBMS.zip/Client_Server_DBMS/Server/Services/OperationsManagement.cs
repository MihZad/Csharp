﻿using Grpc.Core;

namespace Server.Services
{
    public class Omanager : OperationsManagement.OperationsManagementBase
    {
        private readonly ILogger<Omanager> _logger;
        public Omanager(ILogger<Omanager> logger)
        {
            _logger = logger;
        }

        public override Task<DataTableSO> PerformFullMultiplication(MultiplicationParameters request, ServerCallContext context)
        {
            var table1 = request.First; var table2 = request.Second;
            DataTableSO dt = new DataTableSO() { Id = -1, Name = "result" };

            for (int i = 0; i < table1.Columns.Count; i++)
                dt.Columns.Add(table1.Columns[i]);
            for (int j = 0; j < table2.Columns.Count; j++)
                dt.Columns.Add(table2.Columns[j]);

            foreach (var r1 in table1.Rows)
                foreach (var r2 in table2.Rows)
                {
                    var row = new DataRowSO();
                    foreach (var d1 in r1.Data) row.Data.Add(d1);
                    foreach (var d2 in r2.Data) row.Data.Add(d2);
                    dt.Rows.Add(row);
                }

            return Task.FromResult(dt);
        }
    }
}
