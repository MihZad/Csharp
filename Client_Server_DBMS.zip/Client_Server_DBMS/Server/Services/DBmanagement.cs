using Grpc.Core;
using System.Text.Json;
using Protobuf.System.Text.Json;
using Google.Protobuf;

namespace Server.Services
{
    public class DBmanager : DBmanagement.DBmanagementBase
    {
        private readonly ILogger<DBmanager> _logger;
        private static readonly Random ClientIdGetter = new Random();
        public DBmanager(ILogger<DBmanager> logger)
        {
            _logger = logger;
        }

        public override Task<ClientDataModel> GetData(ClientDataLookupModel request, ServerCallContext context)
        {
            var result = new ClientDataModel();
            result.ClientId = request.ClientId;
            result.Bases.Add( loadDataBases(request.ClientId) );
            return Task.FromResult(result);
        }
        private static List<DataBaseSO> loadDataBases(int clientID)
        {
            DirectoryInfo d = new DirectoryInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", clientID.ToString()));
            d.Create();
            FileInfo[] DBfiles = d.GetFiles("*.json");

            var result = new List<DataBaseSO>();
            foreach (FileInfo dbf in DBfiles)
            {
                var options = new JsonSerializerOptions();
                options.AddProtobufSupport();
                string json = File.ReadAllText(dbf.FullName);
                DataBaseSO? db = JsonSerializer.Deserialize<DataBaseSO>(json, options);

                if(db != null) {
                    result.Add(db);
                } 
            }
            return result;
        }

        public override Task<DataSavedResponce> SaveData(ClientDataModel request, ServerCallContext context)
        {
            try
            {
                DirectoryInfo d1 = new DirectoryInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data"));
                if (!d1.Exists) d1.Create();
                DirectoryInfo d2 = new DirectoryInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", request.ClientId.ToString() ));
                if (!d2.Exists) d2.Create();
                

                foreach (var b in request.Bases)
                {
                    var options = new JsonSerializerOptions();
                    options.AddProtobufSupport();
                    string json = JsonSerializer.Serialize(b, options);
                    File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data", request.ClientId.ToString(), b.Name + ".json"), json);
                }
                return Task.FromResult(new DataSavedResponce { Success = true });
            }
            catch (Exception ex) {
                return Task.FromResult(new DataSavedResponce { Success = false, Message = ex.Message });
            }

        }
        public override Task<ClientDataLookupModel> GetID(ClientIdRequest request, ServerCallContext context)
        {
            return Task.FromResult(new ClientDataLookupModel { ClientId = ClientIdGetter.Next() });
        }
    }
}